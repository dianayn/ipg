//: [⇐ Previous: 06 - forEach & map](@previous)
//: ## Episode 07: compactMap & flatMap

//: `compactMap`

// --------------------------------------
let userInput = ["meow!", "15", "37.5", "seven"]
// --------------------------------------






//: `flatMap`

// --------------------------------------
let arrayOfDwarfArrays = [
  ["Sleepy", "Grumpy", "Doc", "Bashful", "Sneezy"],
  ["Thorin", "Nori", "Bombur"]
]
// --------------------------------------



//: [⇒ Next: 08 - Challenge: Closures & Collections](@next)
